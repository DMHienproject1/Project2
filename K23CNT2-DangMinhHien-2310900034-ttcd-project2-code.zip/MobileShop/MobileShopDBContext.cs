﻿internal class MobileShopDBContext
{
}